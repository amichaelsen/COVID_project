# Project To Do List 

## To Do 
* prelimary EDA for daily_reports (CA only)
    * posit some preliminary questions 

## Upcoming 

## Done 
* prelimary EDA for daily_reports (CA only)
    * load tables for dataset 1 
    * explore columns and granularity